<?php
use yii\helpers\Url;
$this->title="Maaf";
?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-6 col-md-offset-3 text-center">
            <br><br>
            <img src="<?php echo Url::base() ?>/img/logo_rsud.jpg" width='50%'>
            <br><br>
            <h><strong><i class="fa fa-smile-o"></i> MAAF, APLIKASI DITUTUP UNTUK SEMENTARA <i class="fa fa-smile-o"></i></strong></h2>
        </div>
    </div>
</div>