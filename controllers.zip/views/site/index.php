<?php

/* @var $this yii\web\View */

$this->title = 'Dashboard';
?>
<div class="site-index">
    <div class="row">
        <div class="col-lg-12">

        </div>
    </div>
</div>