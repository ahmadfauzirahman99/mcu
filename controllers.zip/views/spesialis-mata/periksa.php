<?php
/*
 * @Author: Dicky Ermawan S., S.T., MTA 
 * @Email: wanasaja@gmail.com 
 * @Web: dickyermawan.github.io 
 * @Linkedin: linkedin.com/in/dickyermawan 
 * @Date: 2020-09-13 18:14:13 
 * @Last Modified by: Dicky Ermawan S., S.T., MTA
 * @Last Modified time: 2020-09-16 13:31:01
 */

use app\components\Helper;
use app\models\DataLayanan;
use app\models\spesialis\BaseModel;
use kartik\select2\Select2;
use yii\helpers\Html;
use yii\bootstrap4\ActiveForm;
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $model app\models\spesialis\McuSpesialisMata */
/* @var $form yii\widgets\ActiveForm */

$this->title = 'Pemeriksaan Kesehatan Mata Tenaga Kerja';
$this->params['breadcrumbs'][] = ['label' => 'Unit Medical Check Up', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;

?>

<style type="text/css">
    .form-group {
        margin-bottom: 0px !important;
    }

    .tabel-mata label {
        margin-bottom: 0px !important;
    }
</style>

<div class="mcu-spesialis-audiometri-form">

    <div style="text-align: center;">
        <h3 style="font-weight: bold; margin-bottom: 0px;">Unit Medical Check Up</h3>
        <h3 style="font-weight: bold; margin-top: 0px;"><?= Html::encode($this->title) ?></h3>
    </div>

    <hr>

    <?php $form = ActiveForm::begin([
        'id' => 'form-spesialis-mata',
        'validateOnSubmit' => false, // agar submit ajax tidak 2 kali saat pertama kali reload
    ]); ?>

    <?php
    echo $form->field($model, 'cari_pasien')->widget(Select2::classname(), [
        'data' => BaseModel::getListPasien(),
        'theme' => 'bootstrap',
        'options' => ['placeholder' => 'Cari Pasien ...'],
        'pluginOptions' => [
            'allowClear' => false
        ],
        'pluginEvents' => [
            "select2:select" => "function(e) { 
                window.location = baseUrl + 'spesialis-mata/periksa?no_rm=' + e.params.data.id
            }",
        ],
    ]);
    ?>
    <br>

    <div class="row">
        <div class="col-sm-3">
            <label for="">No. Rekam Medik</label>
            <?php
            $model->no_rekam_medik = $no_rm;
            echo $form->field($model, 'no_rekam_medik')->textInput(['maxlength' => true, 'readonly' => true,])->label(false)
            ?>
        </div>
        <div class="col-sm-9">
            <div class="form-group">
                <label for="">Nama</label>
                <input readonly type="text" class="form-control" value="<?= $pasien->nama ?? null ?>" id="nama_pasien">
            </div>
        </div>
    </div>

    <br>

    <table class="table table-sm tabel-mata">
        <colgroup width="35"></colgroup>
        <colgroup width="268"></colgroup>
        <colgroup width="23"></colgroup>
        <colgroup width="160"></colgroup>
        <colgroup width="226"></colgroup>
        <colgroup width="160"></colgroup>
        <colgroup width="247"></colgroup>
        <tr>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" colspan=3 height="19" align="center" valign=top>
                <font color="#000000"><br></font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" colspan=2 align="center" valign=middle><b>
                    <font color="#000000">MATA KANAN</font>
                </b></td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" colspan=2 align="center" valign=middle><b>
                    <font color="#000000">MATA KIRI</font>
                </b></td>
        </tr>
        <tr>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" rowspan=2 height="38" align="center" valign=top sdval="1" sdnum="1033;">
                <font color="#000000">1</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" rowspan=2 align="left" valign=top>
                <font color="#000000">Persepsi Warna</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" rowspan=2 align="center" valign=top>
                <font color="#000000">:</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <?= Html::activeRadio($model, 'persepsi_warna_mata_kanan',  ['id' => 'mcuspesialismata_persepsi_warna_mata_kanan_0', 'value' => 'Normal', 'label' => 'Normal']) ?>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <label>
                    <input <?= ($model->persepsi_warna_mata_kanan == 'Buta Warna Parsial') ? 'checked' : null ?> type="radio" id="mcuspesialismata_persepsi_warna_mata_kanan_1" name="McuSpesialisMata[persepsi_warna_mata_kanan]" value="Buta Warna Parsial">
                    Buta Warna Parsial
                </label>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <?= Html::activeRadio($model, 'persepsi_warna_mata_kiri',  ['id' => 'mcuspesialismata_persepsi_warna_mata_kiri_0', 'value' => 'Normal', 'label' => 'Normal']) ?>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <label>
                    <input <?= ($model->persepsi_warna_mata_kiri == 'Buta Warna Parsial') ? 'checked' : null ?> type="radio" id="mcuspesialismata_persepsi_warna_mata_kiri_1" name="McuSpesialisMata[persepsi_warna_mata_kiri]" value="Buta Warna Parsial">
                    Buta Warna Parsial
                </label>
            </td>
        </tr>
        <tr>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <font color="#000000"><br></font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <label>
                    <input <?= ($model->persepsi_warna_mata_kanan == 'Buta Warna Total') ? 'checked' : null ?> type="radio" id="mcuspesialismata_persepsi_warna_mata_kanan_2" name="McuSpesialisMata[persepsi_warna_mata_kanan]" value="Buta Warna Total">
                    Buta Warna Total
                </label>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <font color="#000000"><br></font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <label>
                    <input <?= ($model->persepsi_warna_mata_kiri == 'Buta Warna Total') ? 'checked' : null ?> type="radio" id="mcuspesialismata_persepsi_warna_mata_kiri_2" name="McuSpesialisMata[persepsi_warna_mata_kiri]" value="Buta Warna Total">
                    Buta Warna Total
                </label>
            </td>
        </tr>
        <tr>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" height="19" align="center" valign=top sdval="2" sdnum="1033;">
                <font color="#000000">2</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=bottom>
                <font color="#000000">Kelopak Mata</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="center" valign=middle>
                <font color="#000000">:</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <?= Html::activeRadio($model, 'kelopak_mata_kanan',  ['id' => 'mcuspesialismata_kelopak_mata_kanan_0', 'value' => 'Normal', 'label' => 'Normal']) ?>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <label>
                    <input <?= ($model->kelopak_mata_kanan == 'Tidak Normal (Oedema)') ? 'checked' : null ?> type="radio" id="mcuspesialismata_kelopak_mata_kanan_1" name="McuSpesialisMata[kelopak_mata_kanan]" value="Tidak Normal (Oedema)">
                    Tidak Normal (Oedema)
                </label>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <?= Html::activeRadio($model, 'kelopak_mata_kiri',  ['id' => 'mcuspesialismata_kelopak_mata_kiri_0', 'value' => 'Normal', 'label' => 'Normal']) ?>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <label>
                    <input <?= ($model->kelopak_mata_kiri == 'Tidak Normal (Oedema)') ? 'checked' : null ?> type="radio" id="mcuspesialismata_kelopak_mata_kiri_1" name="McuSpesialisMata[kelopak_mata_kiri]" value="Tidak Normal (Oedema)">
                    Tidak Normal (Oedema)
                </label>
            </td>
        </tr>
        <tr>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" rowspan=2 height="38" align="center" valign=top sdval="3" sdnum="1033;">
                <font color="#000000">3</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" rowspan=2 align="left" valign=top>
                <font color="#000000">Konjungtiva</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" rowspan=2 align="center" valign=top>
                <font color="#000000">:</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <?= Html::activeRadio($model, 'konjungtiva_mata_kanan',  ['id' => 'mcuspesialismata_konjungtiva_mata_kanan_0', 'value' => 'Normal', 'label' => 'Normal']) ?>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <label>
                    <input <?= ($model->konjungtiva_mata_kanan == 'Hiperemesis') ? 'checked' : null ?> type="radio" id="mcuspesialismata_konjungtiva_mata_kanan_1" name="McuSpesialisMata[konjungtiva_mata_kanan]" value="Hiperemesis">
                    Hiperemesis
                </label>
                <label style="margin-left: 20px;">
                    <input <?= ($model->konjungtiva_mata_kanan == 'Sekret (-)') ? 'checked' : null ?> type="radio" id="mcuspesialismata_konjungtiva_mata_kanan_2" name="McuSpesialisMata[konjungtiva_mata_kanan]" value="Sekret (-)">
                    Sekret (-)
                </label>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <?= Html::activeRadio($model, 'konjungtiva_mata_kiri',  ['id' => 'mcuspesialismata_konjungtiva_mata_kiri_0', 'value' => 'Normal', 'label' => 'Normal']) ?>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <label>
                    <input <?= ($model->konjungtiva_mata_kiri == 'Hiperemesis') ? 'checked' : null ?> type="radio" id="mcuspesialismata_konjungtiva_mata_kiri_1" name="McuSpesialisMata[konjungtiva_mata_kiri]" value="Hiperemesis">
                    Hiperemesis
                </label>
                <label style="margin-left: 20px;">
                    <input <?= ($model->konjungtiva_mata_kiri == 'Sekret (-)') ? 'checked' : null ?> type="radio" id="mcuspesialismata_konjungtiva_mata_kiri_2" name="McuSpesialisMata[konjungtiva_mata_kiri]" value="Sekret (-)">
                    Sekret (-)
                </label>
            </td>
        </tr>
        <tr>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <font color="#000000"><br></font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <label>
                    <input <?= ($model->konjungtiva_mata_kanan == 'Pucat') ? 'checked' : null ?> type="radio" id="mcuspesialismata_konjungtiva_mata_kanan_3" name="McuSpesialisMata[konjungtiva_mata_kanan]" value="Pucat">
                    Pucat
                </label>
                <label style="margin-left: 20px;">
                    <input <?= ($model->konjungtiva_mata_kanan == 'Pterigium') ? 'checked' : null ?> type="radio" id="mcuspesialismata_konjungtiva_mata_kanan_4" name="McuSpesialisMata[konjungtiva_mata_kanan]" value="Pterigium">
                    Pterigium
                </label>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <font color="#000000"><br></font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <label>
                    <input <?= ($model->konjungtiva_mata_kiri == 'Pucat') ? 'checked' : null ?> type="radio" id="mcuspesialismata_konjungtiva_mata_kiri_3" name="McuSpesialisMata[konjungtiva_mata_kiri]" value="Pucat">
                    Pucat
                </label>
                <label style="margin-left: 20px;">
                    <input <?= ($model->konjungtiva_mata_kiri == 'Pterigium') ? 'checked' : null ?> type="radio" id="mcuspesialismata_konjungtiva_mata_kiri_4" name="McuSpesialisMata[konjungtiva_mata_kiri]" value="Pterigium">
                    Pterigium
                </label>
            </td>
        </tr>
        <tr>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" height="19" align="center" valign=top sdval="4" sdnum="1033;">
                <font color="#000000">4</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=bottom>
                <font color="#000000">Kesegarisan/Gerak Bola Mata</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="center" valign=middle>
                <font color="#000000">:</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <?= Html::activeRadio($model, 'kesegarisan_gerak_bola_mata_kanan',  ['id' => 'mcuspesialismata_kesegarisan_gerak_bola_mata_kanan_0', 'value' => 'Normal', 'label' => 'Normal']) ?>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <label>
                    <input <?= ($model->kesegarisan_gerak_bola_mata_kanan == 'Strabismus') ? 'checked' : null ?> type="radio" id="mcuspesialismata_kesegarisan_gerak_bola_mata_kanan_1" name="McuSpesialisMata[kesegarisan_gerak_bola_mata_kanan]" value="Strabismus">
                    Strabismus
                </label>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <?= Html::activeRadio($model, 'kesegarisan_gerak_bola_mata_kiri',  ['id' => 'mcuspesialismata_kesegarisan_gerak_bola_mata_kiri_0', 'value' => 'Normal', 'label' => 'Normal']) ?>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <label>
                    <input <?= ($model->kesegarisan_gerak_bola_mata_kiri == 'Strabismus') ? 'checked' : null ?> type="radio" id="mcuspesialismata_kesegarisan_gerak_bola_mata_kiri_1" name="McuSpesialisMata[kesegarisan_gerak_bola_mata_kiri]" value="Strabismus">
                    Strabismus
                </label>
            </td>
        </tr>
        <tr>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" height="19" align="center" valign=top sdval="5" sdnum="1033;">
                <font color="#000000">5</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=bottom>
                <font color="#000000">Skiera</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="center" valign=middle>
                <font color="#000000">:</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <?= Html::activeRadio($model, 'skiera_mata_kanan',  ['id' => 'mcuspesialismata_skiera_mata_kanan_0', 'value' => 'Normal', 'label' => 'Normal']) ?>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <label>
                    <input <?= ($model->skiera_mata_kanan == 'Ikterik') ? 'checked' : null ?> type="radio" id="mcuspesialismata_skiera_mata_kanan_1" name="McuSpesialisMata[skiera_mata_kanan]" value="Ikterik">
                    Ikterik
                </label>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <?= Html::activeRadio($model, 'skiera_mata_kiri',  ['id' => 'mcuspesialismata_skiera_mata_kiri_0', 'value' => 'Normal', 'label' => 'Normal']) ?>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <label>
                    <input <?= ($model->skiera_mata_kiri == 'Ikterik') ? 'checked' : null ?> type="radio" id="mcuspesialismata_skiera_mata_kiri_1" name="McuSpesialisMata[skiera_mata_kiri]" value="Ikterik">
                    Ikterik
                </label>
            </td>
        </tr>
        <tr>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" height="19" align="center" valign=top sdval="6" sdnum="1033;">
                <font color="#000000">6</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=bottom>
                <font color="#000000">Lensa Mata</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="center" valign=middle>
                <font color="#000000">:</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <?= Html::activeRadio($model, 'lensa_mata_kanan',  ['id' => 'mcuspesialismata_lensa_mata_kanan_0', 'value' => 'Tidak Keruh', 'label' => 'Tidak Keruh']) ?>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <label>
                    <input <?= ($model->lensa_mata_kanan == 'Keruh') ? 'checked' : null ?> type="radio" id="mcuspesialismata_lensa_mata_kanan_1" name="McuSpesialisMata[lensa_mata_kanan]" value="Keruh">
                    Keruh
                </label>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <?= Html::activeRadio($model, 'lensa_mata_kiri',  ['id' => 'mcuspesialismata_lensa_mata_kiri_0', 'value' => 'Tidak Keruh', 'label' => 'Tidak Keruh']) ?>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <label>
                    <input <?= ($model->lensa_mata_kiri == 'Keruh') ? 'checked' : null ?> type="radio" id="mcuspesialismata_lensa_mata_kiri_1" name="McuSpesialisMata[lensa_mata_kiri]" value="Keruh">
                    Keruh
                </label>
            </td>
        </tr>
        <tr>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" height="19" align="center" valign=top sdval="7" sdnum="1033;">
                <font color="#000000">7</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=bottom>
                <font color="#000000">Kornea</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="center" valign=middle>
                <font color="#000000">:</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <?= Html::activeRadio($model, 'kornea_mata_kanan',  ['id' => 'mcuspesialismata_kornea_mata_kanan_0', 'value' => 'Normal', 'label' => 'Normal']) ?>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <label>
                    <input <?= ($model->kornea_mata_kanan == 'Tidak Normal') ? 'checked' : null ?> type="radio" id="mcuspesialismata_kornea_mata_kanan_1" name="McuSpesialisMata[kornea_mata_kanan]" value="Tidak Normal">
                    Tidak Normal
                </label>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <?= Html::activeRadio($model, 'kornea_mata_kiri',  ['id' => 'mcuspesialismata_kornea_mata_kiri_0', 'value' => 'Normal', 'label' => 'Normal']) ?>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <label>
                    <input <?= ($model->kornea_mata_kiri == 'Tidak Normal') ? 'checked' : null ?> type="radio" id="mcuspesialismata_kornea_mata_kiri_1" name="McuSpesialisMata[kornea_mata_kiri]" value="Tidak Normal">
                    Tidak Normal
                </label>
            </td>
        </tr>
        <tr>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" height="19" align="center" valign=top sdval="8" sdnum="1033;">
                <font color="#000000">8</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=bottom>
                <font color="#000000">Bulu Mata</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="center" valign=middle>
                <font color="#000000">:</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <?= Html::activeRadio($model, 'bulu_mata_kanan',  ['id' => 'mcuspesialismata_bulu_mata_kanan_0', 'value' => 'Normal', 'label' => 'Normal']) ?>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <label>
                    <input <?= ($model->bulu_mata_kanan == 'Tidak Normal') ? 'checked' : null ?> type="radio" id="mcuspesialismata_bulu_mata_kanan_1" name="McuSpesialisMata[bulu_mata_kanan]" value="Tidak Normal">
                    Tidak Normal
                </label>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <?= Html::activeRadio($model, 'bulu_mata_kiri',  ['id' => 'mcuspesialismata_bulu_mata_kiri_0', 'value' => 'Normal', 'label' => 'Normal']) ?>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <label>
                    <input <?= ($model->bulu_mata_kiri == 'Tidak Normal') ? 'checked' : null ?> type="radio" id="mcuspesialismata_bulu_mata_kiri_1" name="McuSpesialisMata[bulu_mata_kiri]" value="Tidak Normal">
                    Tidak Normal
                </label>
            </td>
        </tr>
        <tr>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" height="19" align="center" valign=top sdval="9" sdnum="1033;">
                <font color="#000000">9</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=bottom>
                <font color="#000000">Tekanan Bola Mata</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="center" valign=middle>
                <font color="#000000">:</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <?= Html::activeRadio($model, 'tekanan_bola_mata_kanan',  ['id' => 'mcuspesialismata_tekanan_bola_mata_kanan_0', 'value' => 'Normal', 'label' => 'Normal']) ?>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <label>
                    <input <?= ($model->tekanan_bola_mata_kanan == 'Tidak Normal') ? 'checked' : null ?> type="radio" id="mcuspesialismata_tekanan_bola_mata_kanan_1" name="McuSpesialisMata[tekanan_bola_mata_kanan]" value="Tidak Normal">
                    Tidak Normal
                </label>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <?= Html::activeRadio($model, 'tekanan_bola_mata_kiri',  ['id' => 'mcuspesialismata_tekanan_bola_mata_kiri_0', 'value' => 'Normal', 'label' => 'Normal']) ?>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <label>
                    <input <?= ($model->tekanan_bola_mata_kiri == 'Tidak Normal') ? 'checked' : null ?> type="radio" id="mcuspesialismata_tekanan_bola_mata_kiri_1" name="McuSpesialisMata[tekanan_bola_mata_kiri]" value="Tidak Normal">
                    Tidak Normal
                </label>
            </td>
        </tr>
        <tr>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" height="19" align="center" valign=top sdval="10" sdnum="1033;">
                <font color="#000000">10</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=bottom>
                <font color="#000000">Penglihatan 3 dimensi</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="center" valign=middle>
                <font color="#000000">:</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <?= Html::activeRadio($model, 'penglihatan_3_dimensi_mata_kanan',  ['id' => 'mcuspesialismata_penglihatan_3_dimensi_mata_kanan_0', 'value' => 'Normal', 'label' => 'Normal']) ?>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <label>
                    <input <?= ($model->penglihatan_3_dimensi_mata_kanan == 'Tidak Normal') ? 'checked' : null ?> type="radio" id="mcuspesialismata_penglihatan_3_dimensi_mata_kanan_1" name="McuSpesialisMata[penglihatan_3_dimensi_mata_kanan]" value="Tidak Normal">
                    Tidak Normal
                </label>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <?= Html::activeRadio($model, 'penglihatan_3_dimensi_mata_kiri',  ['id' => 'mcuspesialismata_penglihatan_3_dimensi_mata_kiri_0', 'value' => 'Normal', 'label' => 'Normal']) ?>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=top>
                <label>
                    <input <?= ($model->penglihatan_3_dimensi_mata_kiri == 'Tidak Normal') ? 'checked' : null ?> type="radio" id="mcuspesialismata_penglihatan_3_dimensi_mata_kiri_1" name="McuSpesialisMata[penglihatan_3_dimensi_mata_kiri]" value="Tidak Normal">
                    Tidak Normal
                </label>
            </td>
        </tr>
        <tr>
            <td style="border-top: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" rowspan=3 height="58" align="center" valign=top sdval="11" sdnum="1033;">
                <font color="#000000">11</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=bottom>
                <font color="#000000">Virus Mata</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="center" valign=middle>
                <font color="#000000"><br></font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" colspan=2 align="center" valign=middle><b>
                    <font color="#000000">MATA KANAN</font>
                </b></td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" colspan=2 align="center" valign=middle><b>
                    <font color="#000000">MATA KIRI</font>
                </b>
            </td>
        </tr>
        <tr>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=bottom>
                <font color="#000000">a. Tanpa Koreksi</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="center" valign=middle>
                <font color="#000000">:</font>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" colspan=2 align="left" valign=top>
                <?= $form->field($model, 'virus_mata_tanpa_koreksi_mata_kanan')->textInput(['maxlength' => true])->label(false) ?>
            </td>
            <td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" colspan=2 align="left" valign=top>
                <?= $form->field($model, 'virus_mata_tanpa_koreksi_mata_kiri')->textInput(['maxlength' => true])->label(false) ?>
            </td>
        </tr>
        <tr>
            <td style="border-top: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=bottom>
                <font color="#000000">b. Dengan Koreksi</font>
            </td>
            <td style="border-top: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="center" valign=middle>
                <font color="#000000">:</font>
            </td>
            <td style="border-top: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" colspan=2 align="left" valign=top>
                <?= $form->field($model, 'virus_mata_dengan_koreksi_mata_kanan')->textInput(['maxlength' => true])->label(false) ?>
            </td>
            <td style="border-top: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" colspan=2 align="left" valign=top>
                <?= $form->field($model, 'virus_mata_dengan_koreksi_mata_kiri')->textInput(['maxlength' => true])->label(false) ?>
            </td>
        </tr>
        <tr>
            <td style="border-top: 1px solid #000000; border-left: 1px solid #000000" rowspan=3 height="58" align="center" valign=top sdval="12" sdnum="1033;">
                <font color="#000000">12</font>
            </td>
            <td style="border-top: 1px solid #000000" rowspan=3 align="left" valign=top>
                <font color="#000000">Lain-lain</font>
            </td>
            <td style="border-top: 1px solid #000000" rowspan=3 align="center" valign=top>
                <font color="#000000">:</font>
            </td>
            <td style="border-top: 1px solid #000000; border-right: 1px solid #000000" colspan=4 rowspan=3 align="left" valign=top>
                <?= $form->field($model, 'lain_lain')->textArea(['rows' => 4])->label(false) ?>
            </td>
        </tr>
        <tr>
        </tr>
        <tr>
        </tr>
        <tr>
            <td style="border-bottom: 1px solid #000000; border-left: 1px solid #000000" rowspan=3 height="58" align="center" valign=top sdval="13" sdnum="1033;">
                <font color="#000000">13</font>
            </td>
            <td style="border-bottom: 1px solid #000000" rowspan=3 align="left" valign=top><b>
                    <font color="#000000">KESIMPULAN</font>
                </b></td>
            <td style="border-bottom: 1px solid #000000" rowspan=3 align="center" valign=top>
                <font color="#000000">:</font>
            </td>
            <td style="border-bottom: 1px solid #000000; border-right: 1px solid #000000" colspan=4 rowspan=3 align="left" valign=top>
                <?= $form->field($model, 'kesimpulan')->textArea(['rows' => 4])->label(false) ?>
            </td>
        </tr>
        <tr>
        </tr>
        <tr>
        </tr>
    </table>

    <div class="form-group">
        <?php
        if (array_key_exists('no_rm', $_GET))
            echo Html::submitButton('Simpan', ['class' => 'btn btn-success']);
        ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>

<?php

$this->registerJs($this->render('periksa.js'));
